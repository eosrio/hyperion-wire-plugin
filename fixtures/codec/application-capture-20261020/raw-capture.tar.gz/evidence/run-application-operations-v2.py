"""Run an allowlisted, bounded workload on the fresh owned Wire engineering fixture.

The only private input stays in this process and clio's stdin; it is never an
argument, environment variable, file in the public journal, or console output.
"""
import argparse,datetime,hashlib,json,os,pathlib,re,stat,subprocess,time,urllib.request

ROOT=pathlib.Path('/srv/hyperion-wire-testnet/20261020-application-issue2')
EXPECTED_CHAIN='9f70136446c1a3ea95deefbbe4aaeee4f31f16870eba976fcb7054172fbffacf'
ACCOUNTS={'wiremap','wiresec','wireproto','wireorder','wirenotify','wireinline','wireupgrade'}
SHA=lambda value:hashlib.sha256(value).hexdigest()
PARSER=argparse.ArgumentParser()
PARSER.add_argument('--plan',required=True)
PARSER.add_argument('--output',required=True)
ARGS=PARSER.parse_args()
PLAN_PATH=pathlib.Path(ARGS.plan)
OUT=pathlib.Path(ARGS.output)
assert OUT.parent.resolve()==ROOT/'evidence' and not OUT.exists() and not OUT.is_symlink(), 'New direct child of evidence required'
plan_stat=PLAN_PATH.lstat()
assert stat.S_ISREG(plan_stat.st_mode) and plan_stat.st_size<=2*1024*1024, 'Bounded ordinary public plan required'
PINS=json.loads((ROOT/'evidence/capture-public-pins.json').read_bytes())
assert PINS['chainId']==EXPECTED_CHAIN and PINS['httpUrl']=='http://127.0.0.1:18889'
CLIO=PINS['clio']['path']
assert SHA(pathlib.Path(CLIO).read_bytes())==PINS['clio']['sha256']
assert SHA(pathlib.Path(PINS['node']['path']).read_bytes())==PINS['node']['sha256']
assert SHA(pathlib.Path(PINS['genesis']['path']).read_bytes())==PINS['genesis']['sha256']
PLAN=json.loads(PLAN_PATH.read_bytes())
assert PLAN['schemaVersion']==1 and PLAN['chainId']==EXPECTED_CHAIN
assert 1<=len(PLAN['operations'])<=64
assert len({op['id'] for op in PLAN['operations']})==len(PLAN['operations'])
for op in PLAN['operations']:
 assert re.fullmatch(r'[a-z0-9-]{1,64}',op['id'])
 assert 1<=len(op['actions'])<=4
 for action in op['actions']:
  assert action['account'] in ACCOUNTS|{'sysio'}
  assert re.fullmatch(r'[a-z1-5.]{1,12}',action['name'])
  assert 0<len(action['authorization'])<=2
  assert all(auth['actor'] in ACCOUNTS|{'sysio'} and auth['permission']=='active' for auth in action['authorization'])
  if action['account']=='sysio':
   assert action['name'] in {'newaccount','setcode','setabi'}
   assert (action['data'].get('name') if action['name']=='newaccount' else action['data'].get('account')) in ACCOUNTS

DEADLINE=time.monotonic()+240

def remaining(maximum):
 value=DEADLINE-time.monotonic()
 assert value>0, 'Workload wall-clock bound exceeded'
 return min(maximum,value)

def ownership():
 remaining(5)
 process=pathlib.Path('/proc')/str(PINS['node']['pid'])
 assert os.readlink(process/'exe')==PINS['node']['path'], 'Node process identity changed'
 text=(process/'stat').read_text()
 assert text[text.rindex(')')+2:].split()[19]==PINS['node']['startTicks'], 'Node PID was reused'

def rpc(method,body):
 ownership()
 request=urllib.request.Request(PINS['httpUrl']+'/v1/'+method,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(request,timeout=remaining(5)) as response: raw=response.read(2*1024*1024+1)
 remaining(5)
 assert len(raw)<=2*1024*1024
 return json.loads(raw)

BEFORE=rpc('chain/get_info',{})
assert BEFORE['chain_id']==EXPECTED_CHAIN and BEFORE['server_full_version_string']==PINS['node']['serverFullVersion']
assert rpc('producer/paused',{}) is False, 'Resume fixture explicitly before workload'
GENESIS=json.loads(pathlib.Path(PINS['genesis']['path']).read_bytes())
key_file=ROOT/'config/default_signature_providers.json'
key_stat=key_file.lstat()
assert stat.S_ISREG(key_stat.st_mode) and stat.S_IMODE(key_stat.st_mode)==0o600
provider=json.loads(key_file.read_bytes())['chain_key_type_wire']
parts=provider.split(',')
assert len(parts)==5 and parts[1:3]==['wire','wire'] and parts[4].startswith('KEY:')
def canonical_public(public):
 result=subprocess.run([CLIO,'--no-auto-kiod','convert','k1_public_key',public],capture_output=True,timeout=remaining(10))
 remaining(10)
 assert result.returncode==0 and len(result.stdout)<=4096 and len(result.stderr)<=4096
 values=re.findall(rb'PUB_K1_[1-9A-HJ-NP-Za-km-z]+',result.stdout)
 assert len(values)==1
 return values[0]
assert canonical_public(parts[3])==canonical_public(GENESIS['initial_key']), 'Provider public identity differs from genesis owner'
SECRET=parts[4][4:]
assert re.fullmatch(r'(?:PVT_K1_[1-9A-HJ-NP-Za-km-z]+|5[HJK][1-9A-HJ-NP-Za-km-z]{49})',SECRET), 'Unsupported K1 private encoding'

def redacted(data):
 data=data.replace(SECRET.encode(),b'<redacted>')
 return re.sub(rb'PVT_[A-Za-z0-9_]+|5[HJK][1-9A-HJ-NP-Za-km-z]{49}',b'<redacted>',data)

def write(name,data):
 if not isinstance(data,bytes): data=(json.dumps(data,indent=2)+'\n').encode()
 assert len(data)<=4*1024*1024 and SECRET.encode() not in data
 with (OUT/name).open('xb') as handle: handle.write(data); handle.flush(); os.fsync(handle.fileno())

def clio(arguments,stdin=None):
 ownership()
 result=subprocess.run([CLIO,'--no-auto-kiod','--url',PINS['httpUrl']]+arguments,input=stdin,capture_output=True,timeout=remaining(20))
 remaining(20)
 assert len(result.stdout)<=4*1024*1024 and len(result.stderr)<=1024*1024
 if result.returncode:
  raise RuntimeError('Official clio failed: '+redacted(result.stderr[:8192]).decode(errors='replace'))
 assert SECRET.encode() not in result.stdout
 return result.stdout,redacted(result.stderr)

OUT.mkdir(mode=0o700)
write('plan.json',PLAN_PATH.read_bytes())
write('info-before.json',BEFORE)
completed=[]
deadline=DEADLINE
try:
 for index,op in enumerate(PLAN['operations'],1):
  assert time.monotonic()<deadline, 'Workload wall-clock bound exceeded'
  stem=f'{index:03d}-{op["id"]}'
  current=rpc('chain/get_info',{})
  assert current['chain_id']==EXPECTED_CHAIN
  if completed:
   while current['head_block_num']<=completed[-1]['blockNum']:
    assert time.monotonic()<deadline
    time.sleep(0.1); current=rpc('chain/get_info',{})
  write(stem+'-roots.json',{'actions':op['actions']})
  unsigned,build_err=clio(['push','transaction',str(OUT/(stem+'-roots.json')),'-s','-d','-j'])
  unsigned_json=json.loads(unsigned)
  assert unsigned_json.get('signatures',[])==[]
  assert all(isinstance(action['data'],str) and re.fullmatch(r'(?:[0-9a-fA-F]{2})*',action['data']) for action in unsigned_json['actions'])
  write(stem+'-unsigned.json',unsigned)
  signed,sign_err=clio(['sign',str(OUT/(stem+'-unsigned.json')),'--chain-id',EXPECTED_CHAIN],(SECRET+'\n').encode())
  signed_json=json.loads(signed)
  assert len(signed_json['signatures'])==1
  write(stem+'-signed.json',signed)
  result,push_err=clio(['push','transaction',str(OUT/(stem+'-signed.json')),'-s','-j'])
  receipt=json.loads(result)
  write(stem+'-receipt.json',result)
  write(stem+'-stderr.txt',build_err+sign_err+push_err)
  processed=receipt['processed']
  transaction_id=receipt['transaction_id']
  assert re.fullmatch(r'[0-9a-f]{64}',transaction_id) and processed['id']==transaction_id
  assert processed.get('except') is None and processed.get('error_code') in (None,0)
  assert isinstance(processed['receipt'],dict) and isinstance(processed['receipt']['cpu_usage_us'],list)
  block_num=processed['block_num']
  assert type(block_num) is int and block_num>1
  row={'id':op['id'],'transactionId':transaction_id,'blockNum':block_num,'receiptSha256':SHA(result)}
  wait_end=min(deadline,time.monotonic()+30)
  while True:
   after=rpc('chain/get_info',{})
   assert after['chain_id']==EXPECTED_CHAIN
   assert time.monotonic()<wait_end, 'Committed transaction did not become irreversible within bound'
   if after['last_irreversible_block_num']>=row['blockNum']: break
   time.sleep(0.1)
  canonical=rpc('chain/get_block',{'block_num_or_id':str(block_num)})
  assert canonical['block_num']==block_num and re.fullmatch(r'[0-9a-f]{64}',canonical['id'])
  matches=[item for item in canonical['transactions'] if isinstance(item,dict) and isinstance(item.get('trx'),dict) and item['trx'].get('id')==transaction_id]
  assert len(matches)==1 and isinstance(matches[0]['cpu_usage_us'],list), 'Exact transaction absent or duplicated in irreversible block'
  if processed.get('producer_block_id') is not None:
   assert processed['producer_block_id']==canonical['id']
  row['blockId']=canonical['id']
  write(stem+'-canonical-block.json',canonical)
  remaining(5)
  completed.append(row)
  write(stem+'-irreversible.json',after)
 write('summary.json',{'schemaVersion':1,'status':'passed','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'chainId':EXPECTED_CHAIN,'operations':completed,'infoAfter':rpc('chain/get_info',{}),'privateKeysIncluded':False,'scope':'Actual committed-artifact application transactions on isolated engineering node; no selected-testnet claim.'})
 print(json.dumps({'status':'passed','operations':len(completed),'firstBlock':completed[0]['blockNum'],'lastBlock':completed[-1]['blockNum']}))
except BaseException as error:
 write('failure.json',{'schemaVersion':1,'status':'failed','completed':completed,'error':redacted(str(error).encode()).decode(errors='replace')})
 raise
