"""Offline official-clio observations for hash-pinned, deduplicated public source rows."""
import hashlib,importlib.util,json,pathlib,sys
root=pathlib.Path('/srv/hyperion-wire-testnet/20261020-application-issue2')
driver=root/'evidence/range-driver-b40f65d/scripts/capture-wire-range.py'
assert hashlib.sha256(driver.read_bytes()).hexdigest()=='b40f65d1d64e97dc236eb52e6e143feb0571c5f06a632f89f82f1935afe13e23'
spec=importlib.util.spec_from_file_location('bounded_capture',driver)
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
inputs=root/'evidence/row-oracles-inputs-20261020'
plan_bytes=(inputs/'plan.json').read_bytes(); plan=json.loads(plan_bytes)
assert len(plan_bytes)<1024*1024 and plan['schemaVersion']==1 and len(plan['cases'])<=512
assert plan['sourceArchiveSha256']=='9a0b82e070662be562b2da3d4db61f1f7e143f1b32df47fef7a831b120077026'
assert plan['operationsSha256']=='553c7e6a318f1e44f72ba8272759f540c2963d909cf7ae4396f919af68f953a5'
pins=json.loads((root/'evidence/capture-public-pins.json').read_bytes())
assert hashlib.sha256(pathlib.Path(pins['clio']['path']).read_bytes()).hexdigest()==pins['clio']['sha256']
schema=(root/'evidence/capture-application-2-120-final/schema.bin').read_bytes()
assert hashlib.sha256(schema).hexdigest()==pins['handshakeSha256']
deadline=module.Deadline(180)
limits={**module.DEFAULT_LIMITS,'blocks':512,'seconds':180}
output=module.Output(root/'evidence/row-oracles-20261020',limits)
oracle=module.Oracle(pins,output,deadline,limits)
manifest={'schemaVersion':1,'status':'incomplete','sourceArchiveSha256':plan['sourceArchiveSha256'],'planSha256':hashlib.sha256(plan_bytes).hexdigest(),'driverSha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'clio':pins['clio'],'schemaSha256':pins['handshakeSha256'],'cases':[],'scope':'Offline public source row/native ABI observations only; no chain writes, codec execution, wallets or key access. Official serializer full-consumption is not independently certified by this command.'}
try:
 output.write('schema.bin',schema); output.write('plan.json',plan_bytes)
 output.write('capture-driver.py',pathlib.Path(__file__).read_bytes())
 for case in plan['cases']:
  assert case['kind'] in ('row','abi') and case['id']=='case-%04d'%(len(manifest['cases'])+1)
  raw=bytes.fromhex(case['hex']); assert raw.hex()==case['hex'] and len(raw)<=60000
  if case['kind']=='row':
   assert case['typeName'] in {entry['name'] for entry in json.loads(schema)['variants']}
   value=oracle.decode(case['typeName'],raw)
  else:
   value=module.strict_json(oracle.command(['convert','unpack_hex',case['hex']]))
   assert isinstance(value,dict) and value.get('version','').startswith('sysio::abi/')
  manifest['cases'].append({'id':case['id'],'kind':case['kind'],'typeName':case['typeName'],'inputSha256':hashlib.sha256(raw).hexdigest(),'sourceOperationIndices':case['sourceOperationIndices'],'oracleCommandIndex':len(oracle.commands)-1,'decodedFile':output.write('decoded/'+case['id']+'.json',module.json_bytes(value))})
 manifest['status']='observed'
except Exception as error:
 manifest['error']={'type':type(error).__name__,'message':str(error)[:4096]}
finally:
 manifest['commands']=oracle.commands; manifest['files']=list(output.files)
 output.write('manifest.json',module.json_bytes(manifest),final=True)
print(json.dumps({'status':manifest['status'],'cases':len(manifest['cases']),'error':manifest.get('error'),'manifestSha256':hashlib.sha256(module.json_bytes(manifest)).hexdigest()}))
sys.exit(0 if manifest['status']=='observed' else 1)
